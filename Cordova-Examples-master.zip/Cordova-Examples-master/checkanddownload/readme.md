FileSystem/FileTransfer Example
===

This application sees if a particular file exists locally within the app, and
if not, it downloads the file. To use this application you need the FileSystem
and FileTransfer plugins.

	cordova plugin add org.apache.cordova.file
	cordova plugin add org.apache.cordova.file-transfer  

When the application launches, it does the above-mentioned actions. You can
see a bit more if you use a debugger.