Bluemix / Visual Recognition
===

To use this application you need the Camera and FileTransfer plugins.

	cordova plugin add org.apache.cordova.camera
	cordova plugin add org.apache.cordova.file-transfer  
