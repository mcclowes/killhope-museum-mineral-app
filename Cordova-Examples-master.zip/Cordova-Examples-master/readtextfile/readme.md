Read a text file Example
===

This example demonstrates how to read a text file. To run, add the FileSystem
plugin:

    cordova plugin add org.apache.cordova.file

When run, the code will read the contents of index.html and place it
in the textarea.