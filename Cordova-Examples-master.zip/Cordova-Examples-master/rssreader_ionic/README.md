RSS Reader - Ionic version
=====================

Buit with the Ionic framework and uses the following plugins:

*InAppBrowser
*Network-Information

You should use Ionic to create this project so that the default
Ionic plugins used in a project are added automatically.

