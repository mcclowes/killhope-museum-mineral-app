View All Contacts Demo
===

This demo simply demonstrates how to access *all* contacts on a device. It performs a
search with no filter and renders the results to the console. In order to see that data
use remote debugging or GapDebug.

I tweaked the display a bit so it will render contact photos to the DOM. If you have contacts
with photos, they will be displayed.

Please add the following plugins:

	org.apache.cordova.contacts
	
