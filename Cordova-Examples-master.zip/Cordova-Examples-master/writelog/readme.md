Write File Example
===

This application simply demonstrates writing to a file. It uses the file for logging
and wraps the writes in a utility function. Two buttons are used which do nothing (but normally
would) but make use of the log functionality.

Please add the following plugin:

	cordova plugin add org.apache.cordova.file

