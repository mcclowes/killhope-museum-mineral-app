Example uses [PhoneGap File API](http://docs.phonegap.com/en/1.7.0/cordova_file_file.md.html#FileTransfer) to download a remote PDF file and store to sdcard in an application directory.

It also has a function to download and open the PDF file via system intent. For that make sure the device/emulator as a pdf viewer installed. 