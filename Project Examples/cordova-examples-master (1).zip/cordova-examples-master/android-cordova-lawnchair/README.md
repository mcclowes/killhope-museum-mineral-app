android-cordova-lawnchair
================

A simple example to use lawnchair for persistence.